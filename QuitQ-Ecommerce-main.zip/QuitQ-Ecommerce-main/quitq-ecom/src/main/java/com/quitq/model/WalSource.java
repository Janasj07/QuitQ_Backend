package com.quitq.model;

public enum WalSource {
    UPI,
    CARD,
    NETBANKING
}
